﻿using WeatherApi.Models;

namespace WeatherApi.Services;

public interface IWeatherService
{
    // Fetches the location details based on a query (city name, etc.)
    public SearchLocation FetchLocation(string query, string lang = "en");
}
