﻿using WeatherApi.Models;

namespace WeatherApi.Services;

public interface IWeatherService
{
    // Fetches the location details based on a query (city name, etc.)
    public SearchLocation FetchLocation(string query, string lang = "en");

    // Fetches the weather forecast for a location (by query) for a given number of days
    public Weather FetchWeatherForecast(string query, int days = 3, string lang = "en");
}

