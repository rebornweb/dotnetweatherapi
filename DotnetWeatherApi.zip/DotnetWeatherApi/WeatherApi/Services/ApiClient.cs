﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace WeatherApi.Services
{
    public class ApiClient : IApiClient
    {
        private readonly HttpClient _httpClient;

        public ApiClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        // Generic method to make GET requests
        public async Task<T> GetAsync<T>(string url)
        {
            var response = await _httpClient.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<T>();
                return result!;
            }

            throw new HttpRequestException($"API request failed with status code {response.StatusCode}");
        }
    }
}
