﻿using WeatherApi.Models;

namespace WeatherApi.Services;

public class WeatherService : IWeatherService
{
    private static readonly string? WEATHER_API_URL = Environment.GetEnvironmentVariable("WEATHER_API_URL");
    private static readonly string? WEATHER_API_KEY = Environment.GetEnvironmentVariable("WEATHER_API_KEY");
    private static readonly HttpClient _httpClient = new HttpClient { };

    // Fetches the location details based on a query (city name, etc.)
    public SearchLocation FetchLocation(string query, string lang = "en")
    {
        ValidateWeatherApiSettings();

        string apiUrl = $"{WEATHER_API_URL}/weather?q={query}&appid={WEATHER_API_KEY}&lang={lang}";

        HttpResponseMessage response = _httpClient.GetAsync(apiUrl).Result;

        if (response.IsSuccessStatusCode)
        {
            var result = response.Content.ReadFromJsonAsync<SearchLocation>().Result;
            return result; // Returns a SearchLocation object
        }

        throw new HttpRequestException($"Weather API request failed with status code {response.StatusCode}");
    }


    private void ValidateWeatherApiSettings()
    {
        if (string.IsNullOrEmpty(WEATHER_API_URL) || string.IsNullOrEmpty(WEATHER_API_KEY))
        {
            throw new Exception("WEATHER_API_URL and WEATHER_API_KEY must be set in the .env file.");
        }
    }
}
