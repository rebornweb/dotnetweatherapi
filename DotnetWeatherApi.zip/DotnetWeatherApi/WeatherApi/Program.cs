using WeatherApi.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
DotNetEnv.Env.Load("../.env");
builder.Services.AddControllers();

// Register HttpClient (this is added by default in ASP.NET Core)
builder.Services.AddHttpClient();  // Registers HttpClient in the DI container

// Register ApiClient as Scoped, as it depends on HttpClient and handles requests per scope (per request)
builder.Services.AddScoped<IApiClient, ApiClient>();

// Register WeatherService as Singleton
builder.Services.AddSingleton<IWeatherService, WeatherService>();

// Configure Swagger/OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Weather API V1");
});

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
