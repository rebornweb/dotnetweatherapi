﻿namespace WeatherApi.Models
{
    public class SearchLocation
    {
        // Coordinates of the location
        public Coord coord { get; set; }

        // Weather details (can include multiple weather conditions)
        public List<Weather> weather { get; set; }

        // Base used by the weather station
        public string Base { get; set; }

        // Main weather data (temperature, pressure, humidity, etc.)
        public Main main { get; set; }

        // Visibility of the location in meters
        public int visibility { get; set; }

        // Wind data (speed and direction)
        public Wind wind { get; set; }

        // Cloud coverage
        public Clouds clouds { get; set; }

        // Time of data calculation
        public int dt { get; set; }

        // System information (like country, sunrise, sunset)
        public Sys sys { get; set; }

        // Timezone offset from UTC
        public int timezone { get; set; }

        // ID of the city or location
        public int id { get; set; }

        // Name of the location (e.g., city name)
        public string name { get; set; }

        // Response code
        public int cod { get; set; }
    }

    public class Coord
{
    public double lon { get; set; }
    public double lat { get; set; }
}

//public class Weather
//{
//    public int id { get; set; }
//    public string main { get; set; }
//    public string description { get; set; }
//    public string icon { get; set; }
//}

public class Main
{
    public double temp { get; set; }
    public double feels_like { get; set; }
    public double temp_min { get; set; }
    public double temp_max { get; set; }
    public int pressure { get; set; }
    public int humidity { get; set; }
    public int sea_level { get; set; }
    public int grnd_level { get; set; }
}

public class Wind
{
    public double speed { get; set; }
    public int deg { get; set; }
}

public class Clouds
{
    public int all { get; set; }
}

public class Sys
{
    public int type { get; set; }
    public int id { get; set; }
    public string country { get; set; }
    public int sunrise { get; set; }
    public int sunset { get; set; }
}
}
