using Microsoft.AspNetCore.Mvc;
using WeatherApi.Models;
using WeatherApi.Services;

namespace WeatherApi.Controllers;

[ApiController]
[Route("api/")]
public class WeatherForecastController : ControllerBase
{
    private readonly ILogger<WeatherForecastController> _logger;
    private readonly IWeatherService _weatherService;

    public WeatherForecastController(ILogger<WeatherForecastController> logger, IWeatherService weatherService)
    {
        _logger = logger;
        _weatherService = weatherService;
    }

    [HttpGet("search")]
    public ActionResult<SearchLocation> GetSearchLocations(string? q, string? lang = "en")
    {
        if (string.IsNullOrEmpty(q))
        {
            return BadRequest("Query parameter 'q' is required.");
        }

        var result = _weatherService.FetchLocation(query: q, lang: lang!);

        if (result == null)
        {
            return NotFound("Location not found.");
        }

        return Ok(result);
    }

    [HttpGet("forecast")]
    public ActionResult<Weather> GetWeatherForecasts(string? q, int days = 3, string? lang = "en")
    {
        if (string.IsNullOrEmpty(q))
        {
            return BadRequest("Query parameter 'q' is required.");
        }

        var result = _weatherService.FetchWeatherForecast(query: q, days: days, lang: lang!);

        return Ok(result);
    }
}
